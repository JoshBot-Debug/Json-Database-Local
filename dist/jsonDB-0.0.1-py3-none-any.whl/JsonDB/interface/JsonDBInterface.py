import abc

"""
This is the Json DB Interface.
"""

class JsonDBInterface(metaclass=abc.ABCMeta):

    # Defined an Abstract class to avoide any confusion
    def __init__():
        pass